//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 03_leggicolonnaexecution.cs
//  DESCRIZIONE: Leggi colonna execution dai CSV broker
//  RESPONSABILIT�:
//    - Legge colonna executionea e aggiorna UI
//
//  METODI CONTENUTI:
//    - Leggi(string broker, RecuperaPercorsiBroker recuperaBroker) : List<string> [PUBLIC]
//
//  CHIAMATO DA: 00_gestioneletturaconfermeesecuzione.cs
//  CHIAMA: 01_recuperapercorsibroker.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace bridge.latofunzioni.letturaconfirmation.gestionelettureexecution
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE LEGGI COLONNA EXECUTION
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class LeggiColonnaExecution
    {
        public List<string> Leggi(string broker, RecuperaPercorsiBroker recuperaBroker)
        {
            List<string> executionPopolati = new List<string>();

            string path = broker switch
            {
                "Pepperstone" => recuperaBroker.GetPathPepperstone(),
                "XM" => recuperaBroker.GetPathXM(),
                "AVA" => recuperaBroker.GetPathAVA(),
                "FTMO" => recuperaBroker.GetPathFTMO(),
                "FXPRO" => recuperaBroker.GetPathFXPRO(),
                _ => throw new Exception($"Broker non riconosciuto: {broker}")
            };

            string csvPath = Path.Combine(path, "alerts_sendbox.csv");

            if (File.Exists(csvPath))
            {
                string[] righe = File.ReadAllLines(csvPath);
                
                for (int i = 1; i < righe.Length; i++)
                {
                    string[] colonne = righe[i].Split(',');
                    
                    if (colonne.Length >= 12 && !string.IsNullOrEmpty(colonne[11]))
                    {
                        executionPopolati.Add(righe[i]);
                        Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Execution trovato in {broker}: {colonne[0]} - {colonne[11]}");
                    }
                }
            }

            return executionPopolati;
        }
    }
}