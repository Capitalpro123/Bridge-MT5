//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 00_gestioneletturaconfermeesecuzione.cs
//  DESCRIZIONE: Gestione lettura conferme esecuzione
//  RESPONSABILIT�:
//    - Coordina lettura timestamp e execution dai CSV broker
//
//  METODI CONTENUTI:
//    - LeggiConferme() : void [PUBLIC]
//
//  CHIAMATO DA: 01_collegatoreprincipale.cs
//  CHIAMA: 01_recuperapercorsibroker.cs, 02_leggicolonnatimestamp.cs, 03_leggicolonnaexecution.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Diagnostics;

namespace bridge.latofunzioni.letturaconfirmation.gestionelettureexecution
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE GESTIONE LETTURA CONFERME ESECUZIONE
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class GestioneLetturaConfermeEsecuzione
    {
        public void LeggiConferme()
        {
            RecuperaPercorsiBroker recuperaBroker = new RecuperaPercorsiBroker();
            LeggiColonnaTimestamp lettoreTimestamp = new LeggiColonnaTimestamp();
            LeggiColonnaExecution lettoreExecution = new LeggiColonnaExecution();

            string[] brokers = { "Pepperstone", "XM", "AVA", "FTMO", "FXPRO" };

            foreach (string broker in brokers)
            {
                lettoreTimestamp.Leggi(broker, recuperaBroker);
                lettoreExecution.Leggi(broker, recuperaBroker);
            }

            Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Conferme esecuzione lette da tutti i broker");
        }
    }
}