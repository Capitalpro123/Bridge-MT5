//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 02_leggicolonnatimestamp.cs
//  DESCRIZIONE: Leggi colonna timestamp dai CSV broker
//  RESPONSABILIT�:
//    - Legge colonna letturamsea e ritorna lista popolate
//
//  METODI CONTENUTI:
//    - Leggi(string broker, RecuperaPercorsiBroker recuperaBroker) : List<string> [PUBLIC]
//
//  CHIAMATO DA: 00_gestioneletturaconfermeesecuzione.cs
//  CHIAMA: 01_recuperapercorsibroker.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace bridge.latofunzioni.letturaconfirmation.gestionelettureexecution
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE LEGGI COLONNA TIMESTAMP
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class LeggiColonnaTimestamp
    {
        public List<string> Leggi(string broker, RecuperaPercorsiBroker recuperaBroker)
        {
            List<string> timestampPopolati = new List<string>();

            string path = broker switch
            {
                "Pepperstone" => recuperaBroker.GetPathPepperstone(),
                "XM" => recuperaBroker.GetPathXM(),
                "AVA" => recuperaBroker.GetPathAVA(),
                "FTMO" => recuperaBroker.GetPathFTMO(),
                "FXPRO" => recuperaBroker.GetPathFXPRO(),
                _ => throw new Exception($"Broker non riconosciuto: {broker}")
            };

            string csvPath = Path.Combine(path, "alerts_sendbox.csv");

            if (File.Exists(csvPath))
            {
                string[] righe = File.ReadAllLines(csvPath);
                
                for (int i = 1; i < righe.Length; i++)
                {
                    string[] colonne = righe[i].Split(',');
                    
                    if (colonne.Length >= 12 && !string.IsNullOrEmpty(colonne[10]))
                    {
                        timestampPopolati.Add(righe[i]);
                        Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Timestamp trovato in {broker}: {colonne[0]}");
                    }
                }
            }

            return timestampPopolati;
        }
    }
}