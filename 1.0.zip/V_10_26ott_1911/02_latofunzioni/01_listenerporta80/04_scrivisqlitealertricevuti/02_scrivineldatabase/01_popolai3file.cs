﻿//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 01_popolai3file.cs
//  DESCRIZIONE: Popola i 3 file database alert ricevuti
//  RESPONSABILITÀ:
//    - Inserisce dati in SQLite, CSV, TXT
//
//  METODI CONTENUTI:
//    - Inserisci(AlertValidato alert) : void [PUBLIC]
//
//  CHIAMATO DA: 00_scrivineldatabasemanager.cs
//  CHIAMA: Nessuno
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;
using bridge.latofunzioni.listenerporta80.processaalertinentrata;

namespace bridge.latofunzioni.listenerporta80.scrivisqlitealertricevuti.scrivineldatabase
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE POPOLA I 3 FILE
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class PopolaI3File
    {
        private string _pathSQLite;
        private string _pathCSV;
        private string _pathTXT;

        public PopolaI3File(string pathSQLite, string pathCSV, string pathTXT)
        {
            _pathSQLite = pathSQLite;
            _pathCSV = pathCSV;
            _pathTXT = pathTXT;
        }

        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //  METODO PUBBLICO - INSERISCI
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public void Inserisci(AlertValidato alert)
        {
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={_pathSQLite};Version=3;"))
            {
                conn.Open();
                string insert = @"INSERT INTO alerts_received (tradeid, timestampricezione, userid, openclose, lots, direction, symbol, takeprofitpips, stoplosspips, comments) 
                                VALUES (@tradeid, @timestampricezione, @userid, @openclose, @lots, @direction, @symbol, @takeprofitpips, @stoplosspips, @comments)";
                using (SQLiteCommand cmd = new SQLiteCommand(insert, conn))
                {
                    cmd.Parameters.AddWithValue("@tradeid", alert.TradeID);
                    cmd.Parameters.AddWithValue("@timestampricezione", alert.TimestampRicezione);
                    cmd.Parameters.AddWithValue("@userid", alert.UserID);
                    cmd.Parameters.AddWithValue("@openclose", alert.OpenClose);
                    cmd.Parameters.AddWithValue("@lots", alert.Lots);
                    cmd.Parameters.AddWithValue("@direction", alert.Direction);
                    cmd.Parameters.AddWithValue("@symbol", alert.Symbol);
                    cmd.Parameters.AddWithValue("@takeprofitpips", alert.TakeProfitPips);
                    cmd.Parameters.AddWithValue("@stoplosspips", alert.StopLossPips);
                    cmd.Parameters.AddWithValue("@comments", alert.Comments);
                    cmd.ExecuteNonQuery();
                }
            }

            string csvLine = $"{alert.TradeID},{alert.TimestampRicezione},{alert.UserID},{alert.OpenClose},{alert.Lots},{alert.Direction},{alert.Symbol},{alert.TakeProfitPips},{alert.StopLossPips},{alert.Comments}";
            File.AppendAllText(_pathCSV, csvLine + Environment.NewLine);
            File.AppendAllText(_pathTXT, csvLine + Environment.NewLine);
        }
    }
}