//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 04_popolai3file.cs
//  DESCRIZIONE: Popola i 3 file database 2
//  RESPONSABILIT�:
//    - Inserisce dati in SQLite, CSV, TXT per broker specifico
//
//  METODI CONTENUTI:
//    - InserisciPerBroker(AlertValidato alert, string broker, string pathSQLite, string pathCSV, string pathTXT) : void [PUBLIC]
//
//  CHIAMATO DA: 03_inseriscialertdelcsvsendbox.cs
//  CHIAMA: Nessuno
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;
using bridge.latofunzioni.listenerporta80.processaalertinentrata;

namespace bridge.latofunzioni.scritturasucsvdiesecuzione.gestionedatabase2
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE POPOLA I 3 FILE
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class PopolaI3File
    {
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //  METODO PUBBLICO - INSERISCI PER BROKER
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public void InserisciPerBroker(AlertValidato alert, string broker, string pathSQLite, string pathCSV, string pathTXT)
        {
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={pathSQLite};Version=3;"))
            {
                conn.Open();
                string insert = @"INSERT INTO alerts_scritti_csv (tradeid, timestampricezione, userid, openclose, lots, direction, symbol, takeprofitpips, stoplosspips, comments, broker, letturamsea, executionea) 
                                VALUES (@tradeid, @timestampricezione, @userid, @openclose, @lots, @direction, @symbol, @takeprofitpips, @stoplosspips, @comments, @broker, '', '')";
                using (SQLiteCommand cmd = new SQLiteCommand(insert, conn))
                {
                    cmd.Parameters.AddWithValue("@tradeid", alert.TradeID);
                    cmd.Parameters.AddWithValue("@timestampricezione", alert.TimestampRicezione);
                    cmd.Parameters.AddWithValue("@userid", alert.UserID);
                    cmd.Parameters.AddWithValue("@openclose", alert.OpenClose);
                    cmd.Parameters.AddWithValue("@lots", alert.Lots);
                    cmd.Parameters.AddWithValue("@direction", alert.Direction);
                    cmd.Parameters.AddWithValue("@symbol", alert.Symbol);
                    cmd.Parameters.AddWithValue("@takeprofitpips", alert.TakeProfitPips);
                    cmd.Parameters.AddWithValue("@stoplosspips", alert.StopLossPips);
                    cmd.Parameters.AddWithValue("@comments", alert.Comments);
                    cmd.Parameters.AddWithValue("@broker", broker);
                    cmd.ExecuteNonQuery();
                }
            }

            string csvLine = $"{alert.TradeID},{alert.TimestampRicezione},{alert.UserID},{alert.OpenClose},{alert.Lots},{alert.Direction},{alert.Symbol},{alert.TakeProfitPips},{alert.StopLossPips},{alert.Comments},{broker},,";
            File.AppendAllText(pathCSV, csvLine + Environment.NewLine);
            File.AppendAllText(pathTXT, csvLine + Environment.NewLine);

            Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Alert scritto su database 2 per broker {broker}: {alert.TradeID}");
        }
    }
}