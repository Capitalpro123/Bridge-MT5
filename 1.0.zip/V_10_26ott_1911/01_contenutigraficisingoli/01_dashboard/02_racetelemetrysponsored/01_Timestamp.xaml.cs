//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 01_Timestamp.xaml.cs
//  DESCRIZIONE: Componente Timestamp Received
//  RESPONSABILITÀ:
//    - Visualizza valore timestamp
//
//  METODI CONTENUTI:
//    - InitializeComponent() : void [GENERATO AUTO]
//    - ImpostaValore(string valore) : void [PUBLIC]
//
//  CHI CHIAMA: Nessuno (gestito da DataGrid binding)
//  CHI VIENE CHIAMATO: Nessuno
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System.Windows.Controls;

namespace bridge.contenutigraficisingoli.dashboard.racetelemetrysponsored
{
    public partial class Timestamp : UserControl
    {
        public Timestamp()
        {
            InitializeComponent();
        }
        public void ImpostaValore(string valore)
        {
            Dispatcher.Invoke(() =>
            {
                txtTimestamp.Text = valore;
            });
        }
    }
}