//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 02_Asset.xaml.cs
//  DESCRIZIONE: Componente Asset
//  RESPONSABILITÀ:
//    - Visualizza valore asset
//
//  METODI CONTENUTI:
//    - InitializeComponent() : void [GENERATO AUTO]
//    - ImpostaValore(string valore) : void [PUBLIC]
//
//  CHI CHIAMA: Nessuno (gestito da DataGrid binding)
//  CHI VIENE CHIAMATO: Nessuno
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System.Windows.Controls;

namespace bridge.contenutigraficisingoli.dashboard.racetelemetrysponsored
{
    public partial class Asset : UserControl
    {
        public Asset()
        {
            InitializeComponent();
        }
       public void ImpostaValore(string valore)
        {
            Dispatcher.Invoke(() =>
            {
                txtAsset.Text = valore;
            });
        }
    }
}