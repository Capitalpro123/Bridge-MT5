//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 04_UserID.xaml.cs
//  DESCRIZIONE: Componente UserID
//  RESPONSABILITÀ:
//    - Visualizza valore user ID
//
//  METODI CONTENUTI:
//    - InitializeComponent() : void [GENERATO AUTO]
//    - ImpostaValore(string valore) : void [PUBLIC]
//
//  CHI CHIAMA: Nessuno (gestito da DataGrid binding)
//  CHI VIENE CHIAMATO: Nessuno
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System.Windows.Controls;

namespace bridge.contenutigraficisingoli.dashboard.racetelemetrysponsored
{
    public partial class UserID : UserControl
    {
        public UserID()
        {
            InitializeComponent();
        }
        public void ImpostaValore(string valore)
        {
            Dispatcher.Invoke(() =>
            {
                txtUserID.Text = valore;
            });
        }
    }
}