//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 05_Tradecomment.xaml.cs
//  DESCRIZIONE: Componente Trade Comment
//  RESPONSABILITÀ:
//    - Visualizza commento strategia
//
//  METODI CONTENUTI:
//    - InitializeComponent() : void [GENERATO AUTO]
//    - ImpostaValore(string valore) : void [PUBLIC]
//
//  CHI CHIAMA: Nessuno (gestito da DataGrid binding)
//  CHI VIENE CHIAMATO: Nessuno
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System.Windows.Controls;

namespace bridge.contenutigraficisingoli.dashboard.racetelemetrysponsored
{
    public partial class Tradecomment : UserControl
    {
        public Tradecomment()
        {
            InitializeComponent();
        }
        public void ImpostaValore(string valore)
        {
            Dispatcher.Invoke(() =>
            {
                txtComment.Text = valore;
            });
        }
    }
}