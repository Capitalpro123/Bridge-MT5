//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 03_Direction.xaml.cs
//  DESCRIZIONE: Componente Direction
//  RESPONSABILITÀ:
//    - Visualizza direzione trade con colore BUY verde / SELL rosso
//
//  METODI CONTENUTI:
//    - InitializeComponent() : void [GENERATO AUTO]
//    - ImpostaValore(string valore) : void [PUBLIC]
//
//  CHI CHIAMA: Nessuno (gestito da DataGrid binding)
//  CHI VIENE CHIAMATO: Nessuno
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System.Windows.Controls;
using System.Windows.Media;

namespace bridge.contenutigraficisingoli.dashboard.racetelemetrysponsored
{
    public partial class Direction : UserControl
    {
        public Direction()
        {
            InitializeComponent();
        }
        public void ImpostaValore(string valore)
        {
            Dispatcher.Invoke(() =>
            {
                txtDirection.Text = valore;
                
                if (valore.ToUpper() == "BUY")
                {
                    txtDirection.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4EC9B0"));
                }
                else if (valore.ToUpper() == "SELL")
                {
                    txtDirection.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F48771"));
                }
            });
        }
    }
}