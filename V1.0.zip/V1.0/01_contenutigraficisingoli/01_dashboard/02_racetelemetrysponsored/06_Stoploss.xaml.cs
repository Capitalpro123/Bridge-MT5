//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 06_Stoploss.xaml.cs
//  DESCRIZIONE: Componente Stop Loss
//  RESPONSABILITÀ:
//    - Visualizza valore stop loss
//
//  METODI CONTENUTI:
//    - InitializeComponent() : void [GENERATO AUTO]
//    - ImpostaValore(string valore) : void [PUBLIC]
//
//  CHI CHIAMA: Nessuno (gestito da DataGrid binding)
//  CHI VIENE CHIAMATO: Nessuno
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System.Windows.Controls;

namespace bridge.contenutigraficisingoli.dashboard.racetelemetrysponsored
{
    public partial class Stoploss : UserControl
    {
        public Stoploss()
        {
            InitializeComponent();
        }
        public void ImpostaValore(string valore)
        {
            Dispatcher.Invoke(() =>
            {
                txtStoploss.Text = valore;
            });
        }
    }
}