//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 07_Takeprofit.xaml.cs
//  DESCRIZIONE: Componente Take Profit
//  RESPONSABILITÀ:
//    - Visualizza valore take profit
//
//  METODI CONTENUTI:
//    - InitializeComponent() : void [GENERATO AUTO]
//    - ImpostaValore(string valore) : void [PUBLIC]
//
//  CHI CHIAMA: Nessuno (gestito da DataGrid binding)
//  CHI VIENE CHIAMATO: Nessuno
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System.Windows.Controls;

namespace bridge.contenutigraficisingoli.dashboard.racetelemetrysponsored
{
    public partial class Takeprofit : UserControl
    {
        public Takeprofit()
        {
            InitializeComponent();
        }

        public void ImpostaValore(string valore)
        {
            Dispatcher.Invoke(() =>
            {
                txtTakeprofit.Text = valore;
            });
        }
    }
}