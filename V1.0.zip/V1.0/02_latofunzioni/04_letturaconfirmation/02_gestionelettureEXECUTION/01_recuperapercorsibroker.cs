//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 01_recuperapercorsibroker.cs
//  DESCRIZIONE: Recupera percorsi broker per lettura
//  RESPONSABILIT�:
//    - Metodi get per ogni broker
//
//  METODI CONTENUTI:
//    - GetPathPepperstone() : string [PUBLIC]
//    - GetPathXM() : string [PUBLIC]
//    - GetPathAVA() : string [PUBLIC]
//    - GetPathFTMO() : string [PUBLIC]
//    - GetPathFXPRO() : string [PUBLIC]
//
//  CHIAMATO DA: 00_gestioneletturaconfermeesecuzione.cs
//  CHIAMA: 03_leggipathbrokersdatxt.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using bridge.latofunzioni.listenerporta80.setupbase;

namespace bridge.latofunzioni.letturaconfirmation.gestionelettureexecution
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE RECUPERA PERCORSI BROKER
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class RecuperaPercorsiBroker
    {
        private LeggiPathBrokersDaTxtLavoro _lettoreBrokers;

        public RecuperaPercorsiBroker()
        {
            _lettoreBrokers = new LeggiPathBrokersDaTxtLavoro();
        }

        public string GetPathPepperstone()
        {
            return _lettoreBrokers.GetPercorsoPepperstone();
        }

        public string GetPathXM()
        {
            return _lettoreBrokers.GetPercorsoXM();
        }

        public string GetPathAVA()
        {
            return _lettoreBrokers.GetPercorsoAVA();
        }

        public string GetPathFTMO()
        {
            return _lettoreBrokers.GetPercorsoFTMO();
        }

        public string GetPathFXPRO()
        {
            return _lettoreBrokers.GetPercorsoFXPRO();
        }
    }
}