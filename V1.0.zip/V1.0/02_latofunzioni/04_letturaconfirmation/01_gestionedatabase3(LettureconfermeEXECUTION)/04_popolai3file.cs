//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 04_popolai3file.cs
//  DESCRIZIONE: Popola i 3 file database 3
//  RESPONSABILIT�:
//    - Inserisce dati in SQLite, CSV, TXT
//
//  METODI CONTENUTI:
//    - Inserisci(string tradeid, string letturamsea, string executionea, string broker, string pathSQLite, string pathCSV, string pathTXT) : void [PUBLIC]
//
//  CHIAMATO DA: 00_gestioneletturaconfermeesecuzione.cs
//  CHIAMA: Nessuno
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;

namespace bridge.latofunzioni.letturaconfirmation.gestionedatabase3
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE POPOLA I 3 FILE
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class PopolaI3File
    {
        public void Inserisci(string tradeid, string letturamsea, string executionea, string broker, string pathSQLite, string pathCSV, string pathTXT)
        {
            using (SQLiteConnection conn = new SQLiteConnection($"Data Source={pathSQLite};Version=3;"))
            {
                conn.Open();
                string insert = @"INSERT INTO conferme_execution (tradeid, letturamsea, executionea, broker) 
                                VALUES (@tradeid, @letturamsea, @executionea, @broker)";
                using (SQLiteCommand cmd = new SQLiteCommand(insert, conn))
                {
                    cmd.Parameters.AddWithValue("@tradeid", tradeid);
                    cmd.Parameters.AddWithValue("@letturamsea", letturamsea);
                    cmd.Parameters.AddWithValue("@executionea", executionea);
                    cmd.Parameters.AddWithValue("@broker", broker);
                    cmd.ExecuteNonQuery();
                }
            }

            string csvLine = $"{tradeid},{letturamsea},{executionea},{broker}";
            File.AppendAllText(pathCSV, csvLine + Environment.NewLine);
            File.AppendAllText(pathTXT, csvLine + Environment.NewLine);

            Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Conferma execution scritta su database 3: {tradeid}");
        }
    }
}