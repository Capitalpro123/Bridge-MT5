//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 00_gestionescritturaalertdaeseguire.cs
//  DESCRIZIONE: Gestione scrittura alert da eseguire su CSV broker
//  RESPONSABILIT�:
//    - Coordina scrittura alert sui CSV broker
//
//  METODI CONTENUTI:
//    - ScriviAlert(AlertValidato alert) : void [PUBLIC]
//
//  CHIAMATO DA: 01_collegatoreprincipale.cs
//  CHIAMA: 01_recuperapathbroker.cs, 03_inseriscialertdelcsvsendbox.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Diagnostics;
using bridge.latofunzioni.listenerporta80.processaalertinentrata;

namespace bridge.latofunzioni.scritturasucsvdiesecuzione.gestionescritturaalertdaeseguiresucsv
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE GESTIONE SCRITTURA ALERT DA ESEGUIRE
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class GestioneScritturaAlertDaEseguire
    {
        public void ScriviAlert(AlertValidato alert)
        {
            RecuperaPathBroker recuperaBroker = new RecuperaPathBroker();
            InserisciAlertDelCSVSendbox inserisci = new InserisciAlertDelCSVSendbox();
            
            inserisci.Inserisci(alert, recuperaBroker);
            
            Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Alert scritto sui CSV broker: {alert.TradeID}");
        }
    }
}