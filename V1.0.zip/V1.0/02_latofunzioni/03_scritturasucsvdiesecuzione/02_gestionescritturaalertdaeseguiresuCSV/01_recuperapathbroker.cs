//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 01_recuperapathbroker.cs
//  DESCRIZIONE: Recupera path broker per scrittura CSV
//  RESPONSABILIT�:
//    - Metodi get per ogni broker
//
//  METODI CONTENUTI:
//    - GetPathPepperstone() : string [PUBLIC]
//    - GetPathXM() : string [PUBLIC]
//    - GetPathAVA() : string [PUBLIC]
//    - GetPathFTMO() : string [PUBLIC]
//    - GetPathFXPRO() : string [PUBLIC]
//
//  CHIAMATO DA: 00_gestionescritturaalertdaeseguire.cs
//  CHIAMA: 03_leggipathbrokersdatxt.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using bridge.latofunzioni.listenerporta80.setupbase;

namespace bridge.latofunzioni.scritturasucsvdiesecuzione.gestionescritturaalertdaeseguiresucsv
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE RECUPERA PATH BROKER
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class RecuperaPathBroker
    {
        private LeggiPathBrokersDaTxtLavoro _lettoreBrokers;

        public RecuperaPathBroker()
        {
            _lettoreBrokers = new LeggiPathBrokersDaTxtLavoro();
        }

        public string GetPathPepperstone()
        {
            return _lettoreBrokers.GetPercorsoPepperstone();
        }

        public string GetPathXM()
        {
            return _lettoreBrokers.GetPercorsoXM();
        }

        public string GetPathAVA()
        {
            return _lettoreBrokers.GetPercorsoAVA();
        }

        public string GetPathFTMO()
        {
            return _lettoreBrokers.GetPercorsoFTMO();
        }

        public string GetPathFXPRO()
        {
            return _lettoreBrokers.GetPercorsoFXPRO();
        }
    }
}