//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 02_mappaturadelcsv.cs
//  DESCRIZIONE: Mappatura colonne CSV broker
//  RESPONSABILIT�:
//    - Definisce header CSV con colonne letturamsea e executionea
//
//  METODI CONTENUTI:
//    - GetHeader() : string [PUBLIC]
//    - GetRigaCSV(AlertValidato alert) : string [PUBLIC]
//
//  CHIAMATO DA: 03_inseriscialertdelcsvsendbox.cs
//  CHIAMA: Nessuno
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using bridge.latofunzioni.listenerporta80.processaalertinentrata;

namespace bridge.latofunzioni.scritturasucsvdiesecuzione.gestionescritturaalertdaeseguiresucsv
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE MAPPATURA DEL CSV
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class MappaturadelCSV
    {
        public string GetHeader()
        {
            return "tradeid,timestampricezione,userid,openclose,lots,direction,symbol,takeprofitpips,stoplosspips,comments,letturamsea,executionea";
        }

        public string GetRigaCSV(AlertValidato alert)
        {
            return $"{alert.TradeID},{alert.TimestampRicezione},{alert.UserID},{alert.OpenClose},{alert.Lots},{alert.Direction},{alert.Symbol},{alert.TakeProfitPips},{alert.StopLossPips},{alert.Comments},,";
        }
    }
}