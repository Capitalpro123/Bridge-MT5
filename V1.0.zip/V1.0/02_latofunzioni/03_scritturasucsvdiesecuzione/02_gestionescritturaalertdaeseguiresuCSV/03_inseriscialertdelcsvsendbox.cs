//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 03_inseriscialertdelcsvsendbox.cs
//  DESCRIZIONE: Inserisci alert nei CSV sendbox broker
//  RESPONSABILIT�:
//    - Scrive alert nei CSV di tutti i broker
//
//  METODI CONTENUTI:
//    - Inserisci(AlertValidato alert, RecuperaPathBroker recuperaBroker) : void [PUBLIC]
//
//  CHIAMATO DA: 00_gestionescritturaalertdaeseguire.cs
//  CHIAMA: 01_recuperapathbroker.cs, 02_mappaturadelcsv.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Diagnostics;
using System.IO;
using bridge.latofunzioni.listenerporta80.processaalertinentrata;

namespace bridge.latofunzioni.scritturasucsvdiesecuzione.gestionescritturaalertdaeseguiresucsv
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE INSERISCI ALERT DEL CSV SENDBOX
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class InserisciAlertDelCSVSendbox
    {
        public void Inserisci(AlertValidato alert, RecuperaPathBroker recuperaBroker)
        {
            MappaturadelCSV mappatura = new MappaturadelCSV();
            string riga = mappatura.GetRigaCSV(alert);

            string[] brokers = { "Pepperstone", "XM", "AVA", "FTMO", "FXPRO" };
            
            foreach (string broker in brokers)
            {
                string path = broker switch
                {
                    "Pepperstone" => recuperaBroker.GetPathPepperstone(),
                    "XM" => recuperaBroker.GetPathXM(),
                    "AVA" => recuperaBroker.GetPathAVA(),
                    "FTMO" => recuperaBroker.GetPathFTMO(),
                    "FXPRO" => recuperaBroker.GetPathFXPRO(),
                    _ => throw new Exception($"Broker non riconosciuto: {broker}")
                };

                string csvPath = Path.Combine(path, "alerts_sendbox.csv");
                
                if (!File.Exists(csvPath))
                {
                    File.WriteAllText(csvPath, mappatura.GetHeader() + Environment.NewLine);
                }

                File.AppendAllText(csvPath, riga + Environment.NewLine);
                Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Alert inserito in CSV {broker}: {alert.TradeID}");
            }
        }
    }
}