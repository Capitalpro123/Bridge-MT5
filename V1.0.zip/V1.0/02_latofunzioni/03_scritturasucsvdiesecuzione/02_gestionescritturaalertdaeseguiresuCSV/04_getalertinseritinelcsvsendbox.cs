//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 04_getalertinseritinelcsvsendbox.cs
//  DESCRIZIONE: Get alert inseriti nel CSV sendbox
//  RESPONSABILIT�:
//    - Ritorna lista alert inseriti
//
//  METODI CONTENUTI:
//    - GetAlert(string broker) : List<string> [PUBLIC]
//
//  CHIAMATO DA: TBD
//  CHIAMA: 01_recuperapathbroker.cs
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;

namespace bridge.latofunzioni.scritturasucsvdiesecuzione.gestionescritturaalertdaeseguiresucsv
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE GET ALERT INSERITI NEL CSV SENDBOX
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class GetAlertInseritiNelCSVSendbox
    {
        public List<string> GetAlert(string broker)
        {
            RecuperaPathBroker recuperaBroker = new RecuperaPathBroker();
            
            string path = broker switch
            {
                "Pepperstone" => recuperaBroker.GetPathPepperstone(),
                "XM" => recuperaBroker.GetPathXM(),
                "AVA" => recuperaBroker.GetPathAVA(),
                "FTMO" => recuperaBroker.GetPathFTMO(),
                "FXPRO" => recuperaBroker.GetPathFXPRO(),
                _ => throw new Exception($"Broker non riconosciuto: {broker}")
            };

            string csvPath = Path.Combine(path, "alerts_sendbox.csv");
            
            if (File.Exists(csvPath))
            {
                return new List<string>(File.ReadAllLines(csvPath));
            }

            return new List<string>();
        }
    }
}