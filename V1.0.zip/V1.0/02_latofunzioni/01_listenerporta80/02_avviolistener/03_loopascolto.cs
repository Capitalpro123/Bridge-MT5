﻿//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
//  FILE: 03_loopascolto.cs
//  DESCRIZIONE: Loop ascolto HTTP
//  RESPONSABILITÀ:
//    - Loop infinito GetContext()
//    - Per ogni richiesta chiama processaalertmanager su Task.Run()
//    - Non blocca UI
//
//  METODI CONTENUTI:
//    - Avvia(HttpListener) : void [PUBLIC]
//
//  CHIAMATO DA: 00_avviolistenermanager.cs
//  CHIAMA: 00_processaalertmanager.cs
//══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using bridge.latofunzioni.listenerporta80.processaalertinentrata;

namespace bridge.latofunzioni.listenerporta80.avviolistener
{
    //══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    //  CLASSE LOOP ASCOLTO
    //══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    public class LoopAscolto
    {
        //══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
        //  METODO PUBBLICO - AVVIA
        //══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
        public void Avvia(HttpListener listener)
        {
            Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Loop Ascolto - Avviato");

            Task.Run(async () =>
            {
                while (listener.IsListening)
                {
                    try
                    {
                        HttpListenerContext context = await listener.GetContextAsync();
                        
                        Task.Run(() => ProcessaRichiesta(context));
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [ERROR] Errore loop ascolto: {ex.Message}");
                        break;
                    }
                }
            });
        }

        //══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
        //  METODO PRIVATO - PROCESSA RICHIESTA
        //══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
        private void ProcessaRichiesta(HttpListenerContext context)
        {
            try
            {
                using (StreamReader reader = new StreamReader(context.Request.InputStream))
                {
                    string jsonBody = reader.ReadToEnd();
                    Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] Alert ricevuto - Inizio processamento");

                    AlertValidato alertValidato = bridge.latofunzioni.listenerporta80.ListenerPorta80Manager.ProcessaManager.Processa(jsonBody);

                    if (alertValidato != null)
                    {
                 //       bridge.latofunzioni.listenerporta80.ListenerPorta80Manager.AlertsDBManager.InserisciAlert(alertValidato);
                    }

                    byte[] buffer = System.Text.Encoding.UTF8.GetBytes("OK");
                    context.Response.ContentLength64 = buffer.Length;
                    context.Response.OutputStream.Write(buffer, 0, buffer.Length);
                    context.Response.OutputStream.Close();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [ERROR] Errore processamento richiesta: {ex.Message}");
            }
        }
    }
}