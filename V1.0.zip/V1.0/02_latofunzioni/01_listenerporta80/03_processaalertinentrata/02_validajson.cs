//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//  FILE: 02_validajson.cs
//  DESCRIZIONE: Valida JSON alert
//  RESPONSABILIT�:
//    - Deserializza JSON
//    - Verifica tutti i campi esistono
//    - Ritorna AlertJSON o null
//
//  METODI CONTENUTI:
//    - Valida(string) : AlertJSON [PUBLIC]
//
//  CHIAMATO DA: 00_processaalertmanager.cs
//  CHIAMA: Nessuno
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

using System;
using System.Diagnostics;
using Newtonsoft.Json;

namespace bridge.latofunzioni.listenerporta80.processaalertinentrata
{
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //  CLASSE VALIDA JSON
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public class ValidaJSON
    {
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //  METODO PUBBLICO - VALIDA
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public AlertJSON Valida(string jsonBody)
        {
            try
            {
                AlertJSON alert = JsonConvert.DeserializeObject<AlertJSON>(jsonBody);

                if (alert == null ||
                    string.IsNullOrEmpty(alert.password) ||
                    string.IsNullOrEmpty(alert.timestamp) ||
                    string.IsNullOrEmpty(alert.UsedID) ||
                    string.IsNullOrEmpty(alert.openclose) ||
                    string.IsNullOrEmpty(alert.lots) ||
                    string.IsNullOrEmpty(alert.direction) ||
                    string.IsNullOrEmpty(alert.symbol) ||
                    string.IsNullOrEmpty(alert.takeprofitpips) ||
                    string.IsNullOrEmpty(alert.stoplosspips) ||
                    string.IsNullOrEmpty(alert.comments))
                {
                    Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [ERROR] JSON incompleto - Campi mancanti");
                    return null;
                }

                Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [INFO] JSON validato correttamente");
                return alert;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [ERROR] Errore deserializzazione JSON: {ex.Message}");
                return null;
            }
        }
    }
}